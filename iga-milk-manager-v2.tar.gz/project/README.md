# IGA Milk Manager

Automated milk ordering system for IGA Camberwell — PWA + Chrome Extension.

## Project Structure

```
iga-milk-manager/
├── CLAUDE.md                     ← Master context for AI coding assistant
├── SPECS.md                      ← Technical specifications (DB schema, modules, APIs)
├── TASKS.md                      ← Phased task checklist (16 sessions)
├── PITFALLS.md                   ← Known gotchas and edge cases
├── README.md                     ← This file
├── package.json
├── vite.config.ts
├── tailwind.config.js
├── tsconfig.json
├── index.html
│
├── public/
│   ├── manifest.json             ← PWA manifest
│   ├── sw.js                     ← Service worker
│   └── icons/                    ← App icons (192, 512)
│
├── src/
│   ├── main.tsx                  ← App entry point
│   ├── App.tsx                   ← Root component with routing
│   ├── pwa/
│   │   ├── components/
│   │   │   ├── Dashboard.tsx     ← Stock health, alerts, next order countdown
│   │   │   ├── OrderBuilder.tsx  ← Generate, review, approve orders
│   │   │   ├── MarginAnalysis.tsx← Per-SKU margins, supplier comparison
│   │   │   ├── ImportTab.tsx     ← CSV import + Invoice upload
│   │   │   ├── ProductList.tsx   ← Product catalogue management
│   │   │   ├── OrderHistory.tsx  ← Past orders with status
│   │   │   ├── ExpiryTracker.tsx ← Delivery check-in + expiry alerts
│   │   │   └── Settings.tsx      ← Lead time, safety stock, schedule
│   │   ├── lib/
│   │   │   ├── db.ts             ← Dexie database setup with all tables
│   │   │   ├── types.ts          ← All TypeScript interfaces
│   │   │   ├── csvImporter.ts    ← Smart Retail CSV/XLSX parser
│   │   │   ├── invoiceParser.ts  ← Lactalis PDF invoice parser
│   │   │   ├── forecastEngine.ts ← Demand forecasting + reorder suggestions
│   │   │   ├── orderGenerator.ts ← Generate CSV/paste format for Lactalis
│   │   │   ├── priceTracker.ts   ← Price history + margin calculations
│   │   │   └── scheduleManager.ts← Delivery schedule management
│   │   └── data/
│   │       └── seedProducts.ts   ← 45 products from invoice analysis
│   │
│   └── extension/                ← Chrome Extension (Manifest V3)
│       ├── manifest.json
│       ├── background.js         ← Service worker
│       ├── content-scripts/
│       │   ├── main.js           ← Loader, detects which Lactalis page
│       │   ├── quickOrder.js     ← Auto-fill Quick Order with CSV/paste
│       │   └── scheduleScraper.js← Read delivery dates from portal header
│       ├── popup/
│       │   ├── popup.html        ← Extension popup UI
│       │   └── popup.js
│       └── lib/
│           └── storage.js        ← chrome.storage wrapper
│
├── scripts/
│   └── analyzeInvoices.ts        ← One-off script to process bulk invoice data
│
├── tests/
│   ├── csvImporter.test.ts
│   ├── invoiceParser.test.ts
│   └── forecastEngine.test.ts
│
└── docs/
    ├── data-analysis/            ← Invoice analysis outputs, charts
    └── screenshots/              ← Portal screenshots for reference
```

## Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Loading the Chrome Extension

1. Open `chrome://extensions/`
2. Enable "Developer mode" (top right)
3. Click "Load unpacked"
4. Select the `src/extension/` directory
5. The extension icon will appear in your Chrome toolbar
6. Navigate to the Lactalis portal — the extension activates automatically

## Key Flows

### Daily Order Flow
1. Open PWA on phone → Dashboard shows order suggestions
2. Tap "Build Order" → Review and adjust quantities
3. Tap "Approve" → Order saved
4. On PC, open Lactalis portal → Extension shows "1 order ready"
5. Click extension → "Upload Order" → Auto-fills Quick Order page
6. Review on portal → Click "Create Order"

### Weekly Import Flow
1. Export Item Maintenance + Stock Report from Smart Retail
2. Open PWA → Import tab → Upload CSVs
3. System updates product prices, stock levels, calculates velocity

### Invoice Reconciliation Flow
1. Download invoice PDF from Lactalis portal
2. Open PWA → Import tab → Upload invoice
3. System parses, matches to orders, flags discrepancies, updates prices
